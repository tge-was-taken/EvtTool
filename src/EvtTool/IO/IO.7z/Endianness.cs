namespace EvtTool.IO
{
    public enum Endianness
    {
        LittleEndian,
        BigEndian
    }
}